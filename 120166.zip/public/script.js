// script.js
const searchForm = document.getElementById('search-form');
const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');

searchForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const searchTerm = searchInput.value.trim();
  if (searchTerm === '') {
    return;
  }

  try {
    const recipes = await searchRecipes(searchTerm);
    displayRecipes(recipes);
  } catch (error) {
    console.error('Error fetching recipes:', error);
  }
});

async function searchRecipes(searchTerm) {
  // Заменете този код със заявка към вашия сървър за търсене на рецепти
  const response = await fetch(`https://api.example.com/recipes?q=${encodeURIComponent(searchTerm)}`);
  if (!response.ok) {
    throw new Error('Failed to fetch recipes');
  }
  return await response.json();
}

function displayRecipes(recipes) {
  searchResults.innerHTML = ''; // Изчистване на предишните резултати

  if (recipes.length === 0) {
    searchResults.textContent = 'No recipes found';
    return;
  }

  const fragment = document.createDocumentFragment();
  recipes.forEach(recipe => {
    const recipeElement = document.createElement('div');
    recipeElement.classList.add('recipe');
    recipeElement.innerHTML = `
      <h3>${recipe.title}</h3>
      <p>${recipe.description}</p>
      <img src="${recipe.image}" alt="${recipe.title}">
    `;
    fragment.appendChild(recipeElement);
  });
  searchResults.appendChild(fragment);
}
