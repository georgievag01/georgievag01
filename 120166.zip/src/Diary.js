import React, { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Diary() {
  const [weight, setWeight] = useState('');
  const [calories, setCalories] = useState('');
  const [waterIntake, setWaterIntake] = useState('');
  const [notes, setNotes] = useState('');
  const [mood, setMood] = useState('');
  const [savedData, setSavedData] = useState(null); // Създаваме state за съхранение на въведените данни

  const handleSubmit = (e) => {
    e.preventDefault();
    // Тук можеш да напишеш логика за запазване на данните в локално съхранение или изпращане към сървъра
    const data = { weight, calories, waterIntake, notes, mood };
    setSavedData(data); // Запазваме въведените данни в state
    console.log('Данни за дневника:', data);
    // Показваме известие за успешно запазване на данните
    toast.success('Данните са успешно запазени!');
  };

  return (
    <div className="diary">
      <h2>Дневник</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Килограми:
          <input type="text" value={weight} onChange={(e) => setWeight(e.target.value)} />
        </label>
        <label>
          Калории на ден:
          <input type="text" value={calories} onChange={(e) => setCalories(e.target.value)} />
        </label>
        <label>
          Литри вода на ден:
          <input type="text" value={waterIntake} onChange={(e) => setWaterIntake(e.target.value)} />
        </label>
        <label>
          Бележки:
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
        </label>
        <label>
          Настроение:
          <select value={mood} onChange={(e) => setMood(e.target.value)}>
            <option value="Отлично">Отлично</option>
            <option value="Добро">Добро</option>
            <option value="Лошо">Лошо</option>
          </select>
        </label>
        <button type="submit">Запази</button>
      </form>
      {/* Секция за показване на запазените данни */}
      {savedData && (
        <div className="saved-data">
          <h3>Запазени данни:</h3>
          <p>Килограми: {savedData.weight}</p>
          <p>Калории на ден: {savedData.calories}</p>
          <p>Литри вода на ден: {savedData.waterIntake}</p>
          <p>Бележки: {savedData.notes}</p>
          <p>Настроение: {savedData.mood}</p>
        </div>
      )}
      <ToastContainer /> {/* Контейнер за показване на известия */}
    </div>
  );
}

export default Diary;
