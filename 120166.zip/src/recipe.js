// Recipe.js

import React from 'react';
import './recipe.css'; // Импортиране на CSS файла за стиловете на рецептата

function Recipe(props) {
  return (
    <div className="recipe-box"> {/* Добавяне на клас за бокса */}
      <h2>{props.title}</h2>
      <img src={props.image} alt={props.title} />
      <p>{props.description}</p>
      {/* Други данни за рецептата, които искате да покажете */}
    </div>
  );
}

export default Recipe;
